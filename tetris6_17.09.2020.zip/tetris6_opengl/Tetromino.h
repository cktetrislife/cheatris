//
//  Tetromino.h
//  tetris
//
//  Created by Xhacker Liu on 2/13/14.
//  Copyright (c) 2014 Xhacker. All rights reserved.
//

#ifndef __tetris__Tetromino__
#define __tetris__Tetromino__

#include <iostream>
#include "Board.h"

enum Shape {tO, tI, tS, tZ, tL, tJ, tT, t1, tB, tP, tH, tU, NUM_OF_SHAPES};

class Game;

class Tetromino {

private:
    timeval start_time;
    int cur_x;
    int step_extra;
    int rotation_count;
    Shape shape;
    bool blocks[4][4];
    int color_id;
    bool bstop;

    Shape previewshape;
    bool previewblocks[4][4];

    int previewcolor_id;
    bool firstinit;
    int level;

    inline double elapsed(); // const;
    int _steps();
    void _rotate_ccw();
    void _rotate_back();
    void _add_blocks();

public:
    Game *game;
    Board *board;
    Tetromino *tetromino;
    double interval;

    Tetromino();

    void init();
    void reset();

    void left();
    void right();
    void rotate();
    void change();
    void up();
    void down();
    void setlevel(int);
    void stop();
    void start();

    void write_buffer();
    int read_previewblockvertexcount();
    int read_blockvertexcount();
    int previewvertexcount;
    int vertexcount;
};


#endif /* defined(__tetris__Tetromino__) */
