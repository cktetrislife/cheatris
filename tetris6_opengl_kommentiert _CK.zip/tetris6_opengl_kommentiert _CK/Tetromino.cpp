//
//  Tetromino.cpp
//  tetris
//
//  Created by Xhacker Liu on 2/13/14.
//  Copyright (c) 2014 Xhacker. All rights reserved.
//

#include "Tetromino.h"
#include "Game.h"
#include "constants.h"
#include "include/Angel.h"
#include <sys/time.h>
#include <cstring>

const bool shapes[48][4] =
{
    {0, 0, 0, 0},
    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {1, 1, 1, 1},
    {0, 0, 0, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 0, 1, 1},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 0},
    {0, 0, 1, 1},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 1, 0, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 0, 0, 1},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 0, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 0, 0},
    {0, 0, 0, 0},
    {0, 0, 0, 0},

    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 1, 0},
    {0, 1, 1, 1},
    {0, 0, 1, 0},
    {0, 0, 0, 0},

    {0, 1, 0, 1},
    {0, 1, 1, 1},
    {0, 1, 0, 1},
    {0, 0, 0, 0},


    {0, 1, 0, 1},
    {0, 1, 0, 1},
    {0, 1, 1, 1},
    {0, 0, 0, 0},



};
// wieviele quadrate ?
// >4 neu !!
const int shapesize[12]
    {4,4,4,4,4,4,4,1,6,5,7,7
    };



Tetromino::Tetromino()
{
    color_id = rand() % kNumOfColors;
}

inline double Tetromino::elapsed() //verstreichene zeit bestimmen
{
    timeval t;
    gettimeofday(&t, NULL);

    double elapsedTime;
    if (bstop)                      // anhalten - dropstop
    {
    gettimeofday(&start_time, NULL);
    }
    elapsedTime = (t.tv_sec - start_time.tv_sec) * 1000.0;      // sec to ms
    elapsedTime += (t.tv_usec - start_time.tv_usec) / 1000.0;   // us to ms
    return elapsedTime;
}

void Tetromino::init()
{
    firstinit = 0;
    previewshape = (Shape)(rand() % NUM_OF_SHAPES);     // zufall teil in preview

    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }
    color_id = rand() % kNumOfColors;
    previewcolor_id = (color_id + 1) % kNumOfColors;
    previewvertexcount =  shapesize[previewshape] *  4;
    vertexcount = 0;
}

int Tetromino::read_previewblockvertexcount()      // vertexanzahl auslesen lassen
{
    return previewvertexcount;
}

int Tetromino::read_blockvertexcount()
{
    return vertexcount;
}

void Tetromino::reset()         // wenn neues teil eingefügt wird
{
    rotation_count = 0;
    cur_x = 3; // shape outer bound is 4x4
    step_extra = -2;
    bstop = 0;


    // vorschauteil übernehemn -cmk
    // blocks = fallendes tetromino
    shape = previewshape;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            blocks[y][x] = shapes[shape * 4 + y][x];
        }
    }
    color_id = previewcolor_id;
    vertexcount = previewvertexcount;

   // neues vorschauteil
   previewshape = (Shape)(rand() % NUM_OF_SHAPES);
   previewvertexcount =  shapesize[previewshape] *  4;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }

    previewcolor_id = (color_id + 1) % kNumOfColors;

    gettimeofday(&start_time, NULL);

    // neue falltzeit interval berechnen
    interval = kDefaultInterval / pow(kIntervalSpeedUp, 1 + level);
    if (interval < kMinimumInterval) interval = kMinimumInterval;
    if (interval > kDefaultInterval) interval = kDefaultInterval;

}

// level für fallgeschwindigkeit bekommen
void Tetromino::setlevel(int xlevel)
{
level = xlevel;
}


void Tetromino::left()
{       // prüfen auf kollision mit board und boardgrenzen
    if (!board->has_collision(blocks, _steps(), cur_x - 1)) {
        cur_x -= 1;
    }
}

void Tetromino::right()
{
    if (!board->has_collision(blocks, _steps(), cur_x + 1)) {
        cur_x += 1;
    }
}

void Tetromino::rotate()
{
    rotation_count += 1;

    if (shape == tO) {
        ;
    }
    else if (shape == tI || shape == tS || shape == tZ || shape == tH || shape == tB) {
        if (rotation_count % 2 == 0) {
            _rotate_back();
        }
        else {
            _rotate_ccw();
        }
    }
    else if (shape == tL || shape == tJ || shape == tT || shape == tU) {
        _rotate_ccw();
    }
}

// J: um Tetrominos miteinander auszutauschen
void Tetromino::change()
{
    int oldshape;
    bool new_blocks[4][4] = {{0}};

    oldshape = shape;
    switch (shape)
        {
		//tausche tU mit t1
        case tU:
                // neues teil
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[t1 * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(t1);
                vertexcount =  shapesize[t1] *  4;
                }
                break;
        case t1:
        		for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tU * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tU);
                vertexcount =  shapesize[tU] *  4;
                }
                break;
        //tausche Plus- mit H-Tetromino
        case tP:
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tH * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tH);
                vertexcount =  shapesize[tH] *  4;
                }
                break;
        case tH:
                  //
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tP * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tP);
                vertexcount =  shapesize[tP] *  4;
                }
                break;
        //tausche tZ mit tS
        case tZ:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
//                        new_blocks[y][x] = shapes[tS * 4 + y][x];
                          new_blocks[y][x] = blocks[y][3-x];    // gleich in der richtigen rotation tauschen - also spiegeln
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tS);
                vertexcount =  shapesize[tS] *  4;
                }
                break;

        case tS:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
//                        new_blocks[y][x] = shapes[tZ * 4 + y][x];
                           new_blocks[y][x] = blocks[y][3-x];
                   }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tZ);
                vertexcount =  shapesize[tZ] *  4;
                }
                break;
        //tausche tL mit tJ
        case tJ:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                          new_blocks[y][x] = blocks[y][3-x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tL);
                vertexcount =  shapesize[tL] *  4;
                }
                break;

        case tL:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                          new_blocks[y][x] = blocks[y][3-x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tL);
                vertexcount =  shapesize[tL] *  4;
                }
                break;
        //tausche tI mit 2x3 Block
        case tI:
        		for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tB * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tB);
                vertexcount =  shapesize[tB] *  4;
                }
                break;
        case tB:
        		for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tI * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tI);
                vertexcount =  shapesize[tI] *  4;
                }
                break;
        //tausche tT mit 2x2 Block
        case tO:
        		for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tT * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tT);
                vertexcount =  shapesize[tT] *  4;
                }
                break;
        case tT:
        		for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tO * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tO);
                vertexcount =  shapesize[tO] *  4;
                }
                break;

        }


}

void Tetromino::_rotate_ccw()
{
    // pivot is [1][2]
    bool new_blocks[4][4] = {{0}};
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            new_blocks[x][y] = blocks[y][3-x];
        }
    }

    if (!board->has_collision(new_blocks, _steps(), cur_x)) {
        for (int y = 0; y < 4; ++y) {
            for (int x = 0; x < 4; ++x) {
                blocks[y][x] = new_blocks[y][x];
            }
        }
    }
    else {
        rotation_count -= 1;
    }
}

void Tetromino::_rotate_back()
{
    bool new_blocks[4][4] = {{0}};
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            new_blocks[y][x] = shapes[shape * 4 + y][x];
        }
    }

    if (!board->has_collision(new_blocks, _steps(), cur_x)) {
        memcpy(blocks, new_blocks, 4 * 4);
    }
    else {
        rotation_count -= 1;
    }
}

void Tetromino::up()
{
    step_extra -= 1;
}

void Tetromino::down()
{
    step_extra += 1;
    if (board->has_collision(blocks, _steps(), cur_x)) {
        _add_blocks();
    }
}

void Tetromino::stop()
{   // zeitanhalten und step auf "oben" setzen
    bstop = 1;
    step_extra = -1;
}

void Tetromino::start()
{
    bstop = 0;
}

void Tetromino::other()
{
     // neues vorschauteil
   previewshape = (Shape)(rand() % NUM_OF_SHAPES);
   previewvertexcount =  shapesize[previewshape] *  4;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }

    previewcolor_id = (color_id + 1) % kNumOfColors;

}



void Tetromino::_add_blocks()
{   // tetromino ins spielfeld übernehmen
    int rollback = 1;
    while (board->has_collision(blocks, _steps() - rollback, cur_x)) {
        rollback += 1;
    }
    board->add_blocks(blocks, _steps() - rollback, cur_x, color_id,vertexcount);
    reset();
}

int Tetromino::_steps()
{
    return ceil(elapsed() / interval + step_extra);
//    return (step_extra);

}

void Tetromino::write_buffer()
{ // wird von game aufgerufen - zyklisch
    int steps = _steps();

    if (board->has_collision(blocks, steps, cur_x)) {
        if (board->top_reached(blocks, steps)) {
            _add_blocks();
            game->game_over();
            return;
        }
        else {
            _add_blocks();
            return;
        }
    }

    // write buffer for each block in shape
    // schreiben der vertexes in opengl buffer
    int current = 0;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            if (blocks[i][j]) {
                vec2 points[4];
                points[0] = vec2(-W + (j + cur_x    ) * BLOCK_W, H - (i + 1) * BLOCK_H - steps * BLOCK_H);
                points[1] = vec2(-W + (j + cur_x + 1) * BLOCK_W, H - (i + 1) * BLOCK_H - steps * BLOCK_H);
                points[2] = vec2(-W + (j + cur_x    ) * BLOCK_W, H - i * BLOCK_H - steps * BLOCK_H);
                points[3] = vec2(-W + (j + cur_x + 1) * BLOCK_W, H - i * BLOCK_H - steps * BLOCK_H);
                glBufferSubData(GL_ARRAY_BUFFER, (kBeginTetrominoPoints + 4 * current) * sizeof(vec2), sizeof(points), points);

                vec4 color = kDefaultColors[color_id];
                vec4 colors[4] = {color, color, color, color};
                glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset + (kBeginTetrominoPoints + 4 * current) * sizeof(vec4), sizeof(colors), colors);

                current += 1;
            }
        }
    }

    // previewteil vertexes in opengl buffer
    current = 0;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
                if (previewblocks[i][j] )
                {
                vec2 points[4];
                points[0] = vec2(5 * BLOCK_W - (3-j    ) * BLOCK_W, H/2 + (3-i + 1) * BLOCK_H);
                points[1] = vec2(5 * BLOCK_W - (3-j + 1) * BLOCK_W, H/2 + (3-i + 1) * BLOCK_H);
                points[2] = vec2(5 * BLOCK_W - (3-j    ) * BLOCK_W, H/2 + (3-i    ) * BLOCK_H);
                points[3] = vec2(5 * BLOCK_W - (3-j + 1) * BLOCK_W, H/2 + (3-i    ) * BLOCK_H);
                glBufferSubData(GL_ARRAY_BUFFER, (kBeginPreviewPoints + 4 * current) * sizeof(vec2), sizeof(points), points);

                vec4 color = kDefaultColors[blocks[i][j]];
                if (previewblocks[i][j])
                            {
                           color = kDefaultColors[previewcolor_id];
                            }
                else
                    {
                           color = kDefaultColors[kNumOfColors+1];
                    }

                vec4 colors[4] = {color, color, color, color};

    //            assert(0 <= blocks[i][j] && blocks[i][j] < kNumOfColors);

                glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset + (kBeginPreviewPoints + 4 * current) * sizeof(vec4), sizeof(colors), colors);

                current += 1;
                }
        }
    }




}
