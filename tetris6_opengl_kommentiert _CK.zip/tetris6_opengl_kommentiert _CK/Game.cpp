//
//  game.cpp
//  tetris
//
//  Created by Xhacker Liu on 2/13/14.
//  Copyright (c) 2014 Xhacker. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "Game.h"
#include "constants.h"
#include <sys/time.h>
#include <unistd.h>
#include <string.h>

Game *Game::singleton = NULL;

void Game::run(int argc, char **argv)
{
    singleton = this;

    timeval t;
    gettimeofday(&t, NULL);
    srand((unsigned)(t.tv_sec * 1000 + t.tv_usec));

    tetromino.game = singleton;             // das spiel selbst
    tetromino.board = &board;               // 10 * 20 felder
    tetromino.tetromino = &tetromino;       // steine handling

    glutInit(&argc, argv);
#ifdef __APPLE__
    glutInitDisplayMode(GLUT_3_2_CORE_PROFILE | GLUT_RGBA | GLUT_DOUBLE);
#else
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
#endif
    glutInitWindowSize(680, 600);       //340 ->680 cmk
    glutCreateWindow("Cheatris ! by SACMK");

#ifndef __APPLE__
    glewInit();
#endif
    singleton->gamehs = readhighscore();    // hifgscore aus datei

    reset();
    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutIdleFunc(idle);

    glutMainLoop();
}

void Game::init()
{
    vec2 points[kTotalPoints];
    // horizontale linien
    for (int i = 0; i < kNumOfHLines; ++i) {
        points[i * 2    ] = vec2(-W, -H + BLOCK_H * i);
        points[i * 2 + 1] = vec2( 0, -H + BLOCK_H * i);         // cmk x line end begrenzt
    }
    // vertikale linien
    for (int i = 0; i < kNumOfVLines; ++i) {
        points[kNumOfHPoints + i * 2    ] = vec2(-W + BLOCK_W * i, -H);
        points[kNumOfHPoints + i * 2 + 1] = vec2(-W + BLOCK_W * i,  H);
    }
    // horizontale linien Preview -cmk
    for (int i = 0; i < kNumOfHPreviewLines; ++i) {
        points[kNumOfHPoints + kNumOfVPoints + i * 2    ] = vec2( BLOCK_W + 0, H/2 + BLOCK_H * i);
        points[kNumOfHPoints + kNumOfVPoints + i * 2 + 1] = vec2( BLOCK_W * 5, H/2 + BLOCK_H * i);
    }
    // vertikale linien Preview -cmk
    for (int i = 0; i < kNumOfVPreviewLines; ++i) {
        points[kNumOfHPoints + kNumOfVPoints + kNumOfHPreviewPoints + i * 2    ] = vec2(BLOCK_W + BLOCK_W * i, H/2);
        points[kNumOfHPoints + kNumOfVPoints + kNumOfHPreviewPoints + i * 2 + 1] = vec2(BLOCK_W + BLOCK_W * i, H/2 + 4 * BLOCK_H);
    }


    vec4 colors[kTotalPoints];
    for (int i = 0; i < kNumOfHPoints + kNumOfVPoints + kNumOfHPreviewPoints + kNumOfVPreviewPoints; ++i) {
        colors[i] = vec4(0.93, 0.93, 0.93, 1.0);
    }

    GLuint vaoID;
    glGenVertexArrays(1, &vaoID);
    glBindVertexArray(vaoID);

    GLuint vboID;
    glGenBuffers(1, &vboID);
    glBindBuffer(GL_ARRAY_BUFFER, vboID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, kTotalPoints * sizeof(vec2), points);
    glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset, sizeof(colors), colors);

    GLuint program = InitShader("vshader.glsl", "fshader.glsl");
    GLuint vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint vColor = glGetAttribLocation(program, "vColor");
    glEnableVertexAttribArray(vColor);
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(kColorsOffset));

    glClearColor(1.0, 1.0, 1.0, 1.0);

}
// spielneustart
void Game::reset()
{
    tetromino.interval = kDefaultInterval;
    tetromino.init();
    tetromino.reset();
    board.reset();
    singleton->gamehs = readhighscore();
    board.set_highscore(singleton->gamehs);
    is_game_over = false;
}

// ähnlich printf auf pixel skaliert 640 x 600
void Game::textout(int x,int y,int z,const char *format, ...)
    {
        vec4 viewportorg;
        vec4 orthoorg;
        int len, i;
        char printBuffer[1024];
        va_list list;
        va_start(list,format);
        vsprintf(printBuffer, format, list);
        va_end(list);

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();

        glViewport(x,y,5,5);
        gluOrtho2D(0,640,600,0);
        glMatrixMode(GL_MODELVIEW);

        glRasterPos3f(x,y,z);
        glColor3f(0.7,0.78,0.7);

        len = (int) strlen(printBuffer);

        for (i = 0; i < len; i++)
         {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, printBuffer[i]);
         }

        glPopMatrix();
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        gluOrtho2D(-1,1,-1,1);
        glViewport(0,0,640,600);
    }


void Game::display()
{
    int highs;

    highs = singleton->board.get_highscore();
    if (singleton->is_game_over) {
// cmk - schriftausgabe

        textout(132,300,0,"GAME OVER");
        singleton->savehighscore(highs);

    }
    else {
        singleton->tetromino.write_buffer();        // tetromino bearbeiten
        singleton->board.write_buffer();            // spielfeld zeichnen

        glClear(GL_COLOR_BUFFER_BIT);

        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glEnable(GL_CULL_FACE);

        // draw grids immer gleich
        glDrawArrays(GL_LINES, 0, kNumOfHPoints + kNumOfVPoints + kNumOfHPreviewPoints + kNumOfVPreviewPoints);

        // draw current tetromino - durch write_buffer erzeugt fallender stein
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays(GL_TRIANGLE_STRIP, kBeginTetrominoPoints, singleton->tetromino.vertexcount);


        // draw preview - vorschausteil
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays(GL_TRIANGLE_STRIP, kBeginPreviewPoints, singleton->tetromino.previewvertexcount);


        // draw bottom blocks - gefülltes board malen
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays(GL_TRIANGLE_STRIP, kBeginBoardPoints , singleton->board.num_of_points);

    }
    textout(360,550,0,"Preview");

    textout(360,390,0,"HighScore: %d", singleton->board.get_highscore() );
    textout(360,360,0,"Score: %d", singleton->board.get_score() );
    textout(360,330,0,"Level: %d", singleton->board.get_level() );
    singleton->tetromino.setlevel(20 * singleton->board.get_level());       // anpassen der fallzeit per level : kDefaultInterval / 1.01^21

    textout(360,290,0,"Controls");
    textout(360,260,0,"Arrows:");	textout(460,260,0,"left, right, down");
    textout(360,230,0,"Arrow-up:"); textout(460,230,0,"rotate tetromino");

    textout(360,200,0,"U:");textout(460,200,0,"Up");
    textout(360,170,0,"O:");textout(460,170,0,"Change Preview");
    textout(360,140,0,"J:");textout(460,140,0,"Change Shape");
    textout(360,110,0,"K:");textout(460,110,0,"Disable Dropspeed");
    textout(360,80,0,"L:");textout(460,80,0,"Reenable Dropspeed");

    textout(360,50,0,"R:"); textout(460,50,0,"Reset");
    textout(360,20,0,"Q:"); textout(460,20,0,"Quit");

    glutSwapBuffers();
}

void Game::keyboard(unsigned char key, int x, int y)
{
    switch (key) {
        case GLUT_KEY_LEFT:
            singleton->tetromino.left();
            break;
        case GLUT_KEY_RIGHT:
            singleton->tetromino.right();
            break;
        case GLUT_KEY_UP:
            singleton->tetromino.rotate();
            break;
        case GLUT_KEY_DOWN:
            if (!singleton->is_game_over)
                singleton->tetromino.down();
            break;
        case 'u': case 'U':
            singleton->tetromino.up();
            break;
        case 'r': case 'R':
            singleton->reset();
            break;
        case 'k': case 'K':
            singleton->tetromino.stop();
            break;
        case 'l': case 'L':
            singleton->tetromino.start();
            break;

        case 'j': case 'J':
            singleton->tetromino.change();
            break;

        case 'o': case 'O':
            singleton->tetromino.other();
            break;



        case 'q': case 'Q':
        case kKeyCodeESC: case kKeyCodeESC2:
            exit(EXIT_SUCCESS);
            break;
    }
}

void Game::special(int key, int x, int y)
{
    singleton->keyboard(key, x, y);
}

int Game::readhighscore()   // lesen aus datei
{
    FILE *highscorefile;
    int highscoredat;
    highscorefile = fopen("highscore.dat","r");
    if (highscorefile == NULL)
        {
        oldhighscore = 0;
        return 0;
        }
    else
    {
        fread(&highscoredat,sizeof(highscoredat),1,highscorefile);
        fclose(highscorefile);
        oldhighscore = highscoredat;
        return highscoredat;

    }
}

// schreiben des Highscore in datei
void Game::savehighscore(int highscoresave)
{
    FILE *highscorefile;
    int highscoredat;

      if (highscoresave > oldhighscore)
        {

        savehighscore(singleton->gamehs);
        oldhighscore = highscoresave;
        highscoredat = highscoresave;
        highscorefile = fopen("highscore.dat","w");
        fwrite(&highscoredat,sizeof(highscoredat),1,highscorefile);
        fclose(highscorefile);
        }

}

void Game::idle()
{
    usleep(20);
    glutPostRedisplay();
}

void Game::game_over()
{
    is_game_over = true;
}
