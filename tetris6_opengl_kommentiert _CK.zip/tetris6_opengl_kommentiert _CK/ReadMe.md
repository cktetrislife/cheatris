Cheatris

tetris but diffrent

We give you new shapes and controls

by Stefanie Arndt, Christina-Marie Kasassov

Inspired by: https://github.com/xhacker/tetris-opengl

Multimedia, Bergakademie TU Freiberg

controls:

	Arrow-left:		tetromino left
	Arrow-right: 	tetromino right
	Arrow-up: 		rotate tetromino
	Arrow-down: 	fast drop

	R:				reset
	Q:				quit

cheat controls:

	U:				up

	K:				tetromino jumps to top and automatic drop speed is disabled, 
					tetromino can be changed and moved
	L:				reenable automatic dropspeed

	J:				change tetromino shape
						H to +
						U to .
						L to J
						S to Z
						I to 2x3
						T to 2x2

	O:				change preview tetromino randomly



