//
//  Tetromino.cpp
//  tetris
//
//  Created by Xhacker Liu on 2/13/14.
//  Copyright (c) 2014 Xhacker. All rights reserved.
//

#include "Tetromino.h"
#include "Game.h"
#include "constants.h"
#include "include/Angel.h"
#include <sys/time.h>
#include <cstring>

const bool shapes[48][4] =
{
    {0, 0, 0, 0},
    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {1, 1, 1, 1},
    {0, 0, 0, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 0, 1, 1},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 0},
    {0, 0, 1, 1},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 1, 0, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 0, 0, 1},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 1, 1},
    {0, 0, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 0, 0},
    {0, 1, 0, 0},
    {0, 0, 0, 0},
    {0, 0, 0, 0},

    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 1, 1, 0},
    {0, 0, 0, 0},

    {0, 0, 1, 0},
    {0, 1, 1, 1},
    {0, 0, 1, 0},
    {0, 0, 0, 0},

    {0, 1, 0, 1},
    {0, 1, 1, 1},
    {0, 1, 0, 1},
    {0, 0, 0, 0},


    {0, 1, 0, 1},
    {0, 1, 0, 1},
    {0, 1, 1, 1},
    {0, 0, 0, 0},



};
// wieviele quadrate ?
const int shapesize[12]
    {4,4,4,4,4,4,4,1,6,5,7,7
    };



Tetromino::Tetromino()
{
    color_id = rand() % kNumOfColors;
}

inline double Tetromino::elapsed() //const
{
    timeval t;
    gettimeofday(&t, NULL);
    double elapsedTime;
    if (bstop)
    {
    gettimeofday(&start_time, NULL);
    }
    elapsedTime = (t.tv_sec - start_time.tv_sec) * 1000.0;      // sec to ms
    elapsedTime += (t.tv_usec - start_time.tv_usec) / 1000.0;   // us to ms
    return elapsedTime;
}

void Tetromino::init()
{
    firstinit = 0;
    previewshape = (Shape)(rand() % NUM_OF_SHAPES);

    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }
    color_id = rand() % kNumOfColors;
    previewcolor_id = (color_id + 1) % kNumOfColors;
    previewvertexcount =  shapesize[previewshape] *  4;
    vertexcount = 0;
}

int Tetromino::read_previewblockvertexcount()
{
    return previewvertexcount;
}

int Tetromino::read_blockvertexcount()
{
    return vertexcount;
}

void Tetromino::reset()
{
    rotation_count = 0;
    cur_x = 3; // shape outer bound is 4x4
    step_extra = -2;
    bstop = 0;


    // vorschauteil übernehemn -cmk
    shape = previewshape;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            blocks[y][x] = shapes[shape * 4 + y][x];
        }
    }
    color_id = previewcolor_id;
    vertexcount = previewvertexcount;

   // neues vorschauteil
   previewshape = (Shape)(rand() % NUM_OF_SHAPES);
   previewvertexcount =  shapesize[previewshape] *  4;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }

    previewcolor_id = (color_id + 1) % kNumOfColors;

    gettimeofday(&start_time, NULL);

    interval = kDefaultInterval / pow(kIntervalSpeedUp, 1 + level);
    if (interval < kMinimumInterval) interval = kMinimumInterval;
    if (interval > kDefaultInterval) interval = kDefaultInterval;

}

void Tetromino::setlevel(int xlevel)
{
level = xlevel;
}


void Tetromino::left()
{
    if (!board->has_collision(blocks, _steps(), cur_x - 1)) {
        cur_x -= 1;
    }
}

void Tetromino::right()
{
    if (!board->has_collision(blocks, _steps(), cur_x + 1)) {
        cur_x += 1;
    }
}

void Tetromino::rotate()
{
    rotation_count += 1;

    if (shape == tO) {
        ;
    }
    else if (shape == tI || shape == tS || shape == tZ || shape == tH || shape == tB) {
        if (rotation_count % 2 == 0) {
            _rotate_back();
        }
        else {
            _rotate_ccw();
        }
    }
    else if (shape == tL || shape == tJ || shape == tT || shape == tU) {
        _rotate_ccw();
    }
}

void Tetromino::change()
{
    int oldshape;
    bool new_blocks[4][4] = {{0}};

    oldshape = shape;
    switch (shape)
        {
        case tU:
                  // neues vorschauteil
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[t1 * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(t1);
                vertexcount =  shapesize[t1] *  4;
                }
                break;
        case tP:
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tH * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tH);
                vertexcount =  shapesize[tH] *  4;
                }
                break;
        case tH:
                  // neues vorschauteil
                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                        new_blocks[y][x] = shapes[tP * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tP);
                vertexcount =  shapesize[tP] *  4;
                }
                break;

        case tZ:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
//                        new_blocks[y][x] = shapes[tS * 4 + y][x];
                          new_blocks[y][x] = blocks[y][3-x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tS);
                vertexcount =  shapesize[tS] *  4;
                }
                break;

        case tS:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
//                        new_blocks[y][x] = shapes[tZ * 4 + y][x];
                           new_blocks[y][x] = blocks[y][3-x];
                   }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tZ);
                vertexcount =  shapesize[tZ] *  4;
                }
                break;

        case tJ:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
//                        new_blocks[y][x] = shapes[tL * 4 + y][x];
                          new_blocks[y][x] = blocks[y][3-x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tL);
                vertexcount =  shapesize[tL] *  4;
                }
                break;

        case tL:

                for (int y = 0; y < 4; ++y) {
                    for (int x = 0; x < 4; ++x) {
                          new_blocks[y][x] = blocks[y][3-x];
//                        new_blocks[y][x] = shapes[tJ * 4 + y][x];
                    }
                }
                if (!board->has_collision(new_blocks, _steps(), cur_x)) {
                    for (int y = 0; y < 4; ++y) {
                        for (int x = 0; x < 4; ++x) {
                            blocks[y][x] = new_blocks[y][x];
                        }
                    }
                shape = (Shape)(tL);
                vertexcount =  shapesize[tL] *  4;
                }
                break;



        }


}

void Tetromino::_rotate_ccw()
{
    // pivot is [1][2]
    bool new_blocks[4][4] = {{0}};
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            new_blocks[x][y] = blocks[y][3-x];

/*            if (blocks[y][x]) {
                int new_y = 1 - (x - 2);
                int new_x = 2 + (y - 1);
                if (0 <= new_y && new_y < 4 &&
                    0 <= new_x && new_x < 4) {
                    new_blocks[new_y][new_x] = 1;
                }

                assert(new_y >= 0);
                assert(new_y < 4);
                assert(new_x >= 0);
                assert(new_x < 4);
            } */
        }
    }

    if (!board->has_collision(new_blocks, _steps(), cur_x)) {
        for (int y = 0; y < 4; ++y) {
            for (int x = 0; x < 4; ++x) {
                blocks[y][x] = new_blocks[y][x];
            }
        }
    }
    else {
        rotation_count -= 1;
    }
}

void Tetromino::_rotate_back()
{
    bool new_blocks[4][4] = {{0}};
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            new_blocks[y][x] = shapes[shape * 4 + y][x];

  //          assert(shape * 4 + y < 28);
        }
    }

    if (!board->has_collision(new_blocks, _steps(), cur_x)) {
        memcpy(blocks, new_blocks, 4 * 4);
    }
    else {
        rotation_count -= 1;
    }
}

void Tetromino::up()
{
    step_extra -= 1;
}

void Tetromino::down()
{
    step_extra += 1;
    if (board->has_collision(blocks, _steps(), cur_x)) {
        _add_blocks();
    }
}

void Tetromino::stop()
{
    bstop = 1;
    step_extra = -1;
}

void Tetromino::start()
{
    bstop = 0;
}

void Tetromino::other()
{
     // neues vorschauteil
   previewshape = (Shape)(rand() % NUM_OF_SHAPES);
   previewvertexcount =  shapesize[previewshape] *  4;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            previewblocks[y][x] = shapes[previewshape * 4 + y][x];
        }
    }

    previewcolor_id = (color_id + 1) % kNumOfColors;

}



void Tetromino::_add_blocks()
{
    int rollback = 1;
    while (board->has_collision(blocks, _steps() - rollback, cur_x)) {
        rollback += 1;
    }
    board->add_blocks(blocks, _steps() - rollback, cur_x, color_id,vertexcount);
    reset();
}

int Tetromino::_steps()
{
    return ceil(elapsed() / interval + step_extra);
//    return (step_extra);

}

void Tetromino::write_buffer()
{
    int steps = _steps();

    if (board->has_collision(blocks, steps, cur_x)) {
        if (board->top_reached(blocks, steps)) {
            _add_blocks();
            game->game_over();
            return;
        }
        else {
            _add_blocks();
            return;
        }
    }

    // write buffer for each block in shape
    int current = 0;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            if (blocks[i][j]) {
                vec2 points[4];
                points[0] = vec2(-W + (j + cur_x    ) * BLOCK_W, H - (i + 1) * BLOCK_H - steps * BLOCK_H);
                points[1] = vec2(-W + (j + cur_x + 1) * BLOCK_W, H - (i + 1) * BLOCK_H - steps * BLOCK_H);
                points[2] = vec2(-W + (j + cur_x    ) * BLOCK_W, H - i * BLOCK_H - steps * BLOCK_H);
                points[3] = vec2(-W + (j + cur_x + 1) * BLOCK_W, H - i * BLOCK_H - steps * BLOCK_H);
                glBufferSubData(GL_ARRAY_BUFFER, (kBeginTetrominoPoints + 4 * current) * sizeof(vec2), sizeof(points), points);

                vec4 color = kDefaultColors[color_id];
                vec4 colors[4] = {color, color, color, color};
                glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset + (kBeginTetrominoPoints + 4 * current) * sizeof(vec4), sizeof(colors), colors);

                current += 1;
            }
        }
    }

    current = 0;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
                if (previewblocks[i][j] )
                {
                vec2 points[4];
                points[0] = vec2(5 * BLOCK_W - (3-j    ) * BLOCK_W, H/2 + (3-i + 1) * BLOCK_H);
                points[1] = vec2(5 * BLOCK_W - (3-j + 1) * BLOCK_W, H/2 + (3-i + 1) * BLOCK_H);
                points[2] = vec2(5 * BLOCK_W - (3-j    ) * BLOCK_W, H/2 + (3-i    ) * BLOCK_H);
                points[3] = vec2(5 * BLOCK_W - (3-j + 1) * BLOCK_W, H/2 + (3-i    ) * BLOCK_H);
                glBufferSubData(GL_ARRAY_BUFFER, (kBeginPreviewPoints + 4 * current) * sizeof(vec2), sizeof(points), points);

                vec4 color = kDefaultColors[blocks[i][j]];
                if (previewblocks[i][j])
                            {
                           color = kDefaultColors[previewcolor_id];
                            }
                else
                    {
                           color = kDefaultColors[kNumOfColors+1];
                    }

                vec4 colors[4] = {color, color, color, color};

    //            assert(0 <= blocks[i][j] && blocks[i][j] < kNumOfColors);

                glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset + (kBeginPreviewPoints + 4 * current) * sizeof(vec4), sizeof(colors), colors);

                current += 1;
                }
        }
    }




}
